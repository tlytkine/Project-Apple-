<!-- Displayed when a user tries to acces a page either
	while not logged in, or a page that they do not have access to,
	ex: a student logging in to the system admin page-->
<!DOCTYPE html>
<html>
<head>
	<title>Wrong Permissions</title>
	<link rel ="stylesheet" type="text/css" href="style1.css"/>
</head>
<body>
	<b>Sorry, you do not have permission to access this page</b>
	<br>
	<b><a href="logout.php">Log Out</a></b>
</body>
</html>