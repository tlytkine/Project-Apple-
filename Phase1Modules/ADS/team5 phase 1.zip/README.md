# Team5

### Username / Database name: team5
### Password: 9GcBpHaf

### [Link to Website](http://seasdb.seas.gwu.edu/~team5/login.php)

## Login Information

| Username  | Password | Role |
| ------------- | ------------- |------------- |
| PaulMcCartney | Paul  | Student |
| GeorgeHarrison | George | Student |
| EricClapton | Eric | Alumni |
| Wood | wood | Faculty Advisor |
| admin | password | System Admin |
| Narahari | Narahari | Grad Secretary |

## To do: 

* <strike>Remove Faculty Button</strike>
* <strike>Fix students query</strike>

* <strike>Add column to advises for hold and insert hold when inserting new graduate student</strike>
* <strike>Faculty Advisor will be able to remove this new hold off of graduate students but the ones already inserted won't have any holds (this will be the lift hold button on the faculty advisor page that will update the advises table)</strike>
* Make sure that the system admin page can perform all the functions of the other users  
* <strike>Your main page must have a “RESET” button.
The reset will bring your database to a starting state (i.e., erase all the data and populate it with the data specified below and any other test data that you wish to add). The reset is nothing but a bunch of delete statements followed by insert statements.</strike>

* <strike> Add link that lists program requirements for MS in CS degree, in general the program requirements for the degree are stored in the system. This will allow changes to the program requirements to be made if necessary. <- This means that we need to put the program requirements into a table and check them according to the table in case we need to add more degrees or if the program requirements need to be changed. </strike>


## System administrator 
* <strike>Must be able to view applications</strike>
* <strike>Must be able to view students, their personal information / transcripts</strike>
* <strike>Make add student button functional</strike>
* <strike>Make add faculty button functional</strike>
* <strike>Make add alumni button functional</strike>


## Grad Secretary (GS) 

* <strike>A student admitted to the university is assigned a faculty advisor by the GS </strike>
* <strike>Has complete access to applicants data and to current students data. They are responsible for updating status of applicant, matriculating a student (changing an admitted applicant to a current student once the student enrolls at GW) and clearing a student for graduation </strike>
* <strike>GS must be able to approve graduation by clicking on some selection, must be able to view folder aka personal information and transcript</strike>

## Faculty Advisors 
* <strike>These are faculty in the department</strike>
* <strike>They can view their advisees transcript but cannot update the transcript. This is the only access they are given.</strike>
* <strike>They can view all information about an applicant but cannot enter a review. </strike>

## Current Graduate Students
* <strike>They can view their transcript (but cannot update it) and can apply for graduation</strike>
* <strike>They can update their personal information (address, email, etc) but no other information</strike>
* <strike>Since the firstname, lastname, gwid are all fetched from the db and displayed, should they still be textboxes, which allows user to change those fields?</strike>

## Alumni 

*<strike>An alumni can only edit their personal information (such as email, address)</strike> 
* <strike>Add degree to alumni page and the year they received the degree</strike>
* <strike>Make a field for GWID in the Alumni page so the query for editing personal information will only go through if their GWID is entered correctly</strike>

## Audit
* <strike>still need to check for duplicate classes</strike>
* <strike>A student must take at least 10 courses, each which is 3 credits</strike>
* <strike>A student must complete at least 30 credit hours </strike>
* <strike>A student must take the three core courses (CS6221,CS6461,CS6212)</strike> 
* <strike> A student can have at most 2 grades below B- </strike>
* <strike>A student must have a minimum GPA of 3.0 </strike>
* <strike>When a student graduates they are removed from the Graduate student table and their information is entered into an Alumni table (summary of academic information should be kept in the Alumni table)</strike> 

## Comments and further information
* <strike>The advising system will also serve both as an advising system for current students as well as info on alumni (what degree, when, etc) Furthermore the system should have the ability to scale and handle different degrees (and requirements)</strike>
* <strike>Program requirements for the degree (in your project, only the MS degree) are stored in the system. This will allow changes to the program requirements to be made if necessary.</strike>
* <strike>Since Alumni information will be stored we should allow alumni to access the system to perform some queries</strike>

